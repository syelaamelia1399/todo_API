const todos = [];

module.exports = { todos };
